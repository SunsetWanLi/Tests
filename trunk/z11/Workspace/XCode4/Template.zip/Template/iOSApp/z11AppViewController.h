//
//  AppViewController.h
//  iOSApp
//
//  Created by Wang ZhiPeng on 11-5-25.
//  Copyright 2011年 Zhejiang University. All rights reserved.
//
#import "iOSAppViewController.h"

using namespace z11;

@interface z11AppViewController : iOSAppViewController {
    
}

@end

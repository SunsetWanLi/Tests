//////////////////////////////////////////////////////////////////////////
///    COPYRIGHT NOTICE
///    Copyright (c) 2011 Zhejiang University.
///    All rights reserved.
///
/// @file    (android_wrapper.cpp)
/// @brief (Android 的android_wrapper)
///
///(android 的入口函数)
///
/// @version 0.1   (版本声明)
/// @author        (Gu RongFang)
/// @date          (11-07-26)
///
///
///    修订说明：最初版本
//////////////////////////////////////////////////////////////////////////
#ifndef _ANDROID_WRAPPER_CPP_
#define _ANDROID_WRAPPER_CPP_
#include <jni.h>
#include "System/Shared/MGLog.h"
#include "Platform/MGApplication_platform.h"
#include "../../Application/GUIRootView/GUIRootViewController.h"
using namespace z11;
class  AppDelegate : public z11::MGApplication
{
public:
    virtual bool applicationDidFinishLaunching()
	{
		MGApplication::applicationDidFinishLaunching();
        gui_root = GUIRootViewController::getInstance(false);
        gui_root->initManually();
		return true;
	}
};
#ifdef __cplusplus
extern "C" {
#endif

    void
    Java_com_z11_mobile_framework_MGActivity_nativeInit( JNIEnv*  env , jobject  thiz,jint w, jint h)
    {
        z11::MGDevice::setScreenWidthAndHeight(w,h);
		static bool bFirst=true;
		if(bFirst)
		{
			z11::MGLogD("bFirst true");
			AppDelegate *pAppDelegate = new AppDelegate();
			bFirst=false;
			
			// z11::MGLogD("Java_com_z11_mobile_framework_MGRenderer_nativeInit test WebService");
			// z11::MGRequestSoapObject *m_request_soap_object = new z11::MGRequestSoapObject("http://192.168.2.244/IProService.asmx","http://tempuri.org/","HelloWorld");
			// callWebService(m_request_soap_object);
		}
		else
		{
			return ;
//            z11::MGLogD("bFirst false");
//            z11::MGImage::recoveryContext();
//            z11::GuiContainer::container->light_graphic->setProjectionMode();
		}
    }

#ifdef __cplusplus
}
#endif


#endif //_ANDROID_WRAPPER_CPP_

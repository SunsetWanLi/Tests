/* arminstr.h espically created for EV3 project 
*
* For evc4 already have these stuff as a pre-require,
* for evc3 make such a fake assert.h to make affect the lease for the trunk.
*
*/

#ifndef __ARMINSTR_H
#define __ARMINSTR_H
#endif